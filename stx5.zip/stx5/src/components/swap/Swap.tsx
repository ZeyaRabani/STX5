"use client"

import React, { useState, useEffect } from 'react'
import { useWallet } from '@/context/WalletContext'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { request } from 'sats-connect'
import MaxWidthWrapper from '@/components/MaxWidthWrapper'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { RotateCw, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { Form, FormControl, FormField, FormItem, FormMessage } from '@/components/ui/form'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import Image from 'next/image'
import { Skeleton } from '@/components/ui/skeleton'

interface BTCPriceResponse {
    data: {
        amount: string;
        base: string;
        currency: string;
    };
}

const paymentMethod = [
    'STX'
]

const stx5Amount = [
    '1',
    '2',
    '3',
    '4',
    '5'
]

const stx5 = [
    'STX 5'
]

const FormSchema = z.object({
    payment_method: z.string({
        required_error: 'Please select a payment method',
    }),
    stx_amount: z.string({
        required_error: 'Please select the number of STX 5 tokens to receive',
    }),
    stx5_token: z.string({
        required_error: 'Please select the STX 5 token to receive',
    }),
})

export default function Swap() {
    const [stxAmount, setstxAmount] = useState<string>('');
    const [coinbaseData, setCoinbaseData] = useState<number[]>([]);
    const [coingeckoData, setCoingeckoData] = useState<number[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [swaping, setSwaping] = useState<boolean>(false);

    const { isConnected, paymentAddress } = useWallet();

    const fetchSTXPrice = async () => {
        try {
            const response = await fetch('https://api.coinbase.com/v2/prices/STX-USD/buy');
            const data: BTCPriceResponse = await response.json();
            setstxAmount(data.data.amount);
        } catch (error) {
            toast.error('Error fetching STX price. Please try again!');
        }
    };

    useEffect(() => {
        const fetchData = () => {
            fetchSTXPrice();
        }

        fetchData();

        // const intervalId = setInterval(fetchData, 30000);
        // return () => clearInterval(intervalId);
    }, []);

    useEffect(() => {
        const fetchCoinbaseData = async () => {
            const assets = ['STX', 'MAPO', 'ICP', 'RIF'];
            try {
                const coinbaseRequests = assets.map(async (asset) => {
                    const response = await fetch(`https://api.coinbase.com/v2/prices/${asset}-USD/buy`);
                    const data = await response.json();
                    return parseFloat(data.data.amount);
                });
                const result = await Promise.all(coinbaseRequests);
                setCoinbaseData(result);
            } catch (error) {
                // console.error('Error fetching Coinbase data:', error);
            }
        };

        const fetchCoingeckoData = async () => {
            try {
                const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=conflux-token,sovryn');
                const data = await response.json();
                const prices = data.map((item: any) => item.current_price);
                setCoingeckoData(prices);
            } catch (error) {
                // console.error('Error fetching Coingecko data:', error);
            }
        };

        fetchCoinbaseData();
        fetchCoingeckoData();
    }, []);

    useEffect(() => {
        setLoading(false);
    }, [coinbaseData, coingeckoData]);

    const form = useForm<z.infer<typeof FormSchema>>({
        resolver: zodResolver(FormSchema),
        defaultValues: {
            payment_method: 'STX',
            stx_amount: '1',
            stx5_token: 'STX 5'
        },
    });

    const refreshData = () => {
        fetchSTXPrice();
        toast.info('Data refreshed');
    }

    async function onSubmit(values: z.infer<typeof FormSchema>) {
        try {
            if (isConnected) {
                const recepiantAddressSTX = 'ST1SAX5AM1E593ZMTY8XEFCGQ45Q7J7ME38Q7K3FP'
                let sig: string | undefined;
                setSwaping(true);
                const stxPayment = (parseInt(values.stx_amount) * parseFloat(stxAmount)).toFixed(6);
                const microstacksPayment = (parseFloat(stxPayment) * 1e6).toFixed(0);

                const response = await request('stx_transferStx', {
                    recipient: recepiantAddressSTX,
                    amount: Number(microstacksPayment)
                });

                if (response.status === 'success') {
                    sig = response.result.txid;
                    toast.success('Transaction successful!');
                } else {
                    if (response.error.message === 'User rejected the Stacks transaction signing request') {
                        toast.error('Transaction canceled!');
                    } else {
                        toast.error('An error occurred while processing your request. Please try again!');
                    }
                }

                setSwaping(false);
            }
        }
        catch (error) {
            setSwaping(false);
            toast.error('An error occurred while processing your request. Please try again!');
        }
    }

    return (
        <MaxWidthWrapper>
            <div className='flex flex-col py-4 md:py-8 h-full items-center justify-center'>
                {loading ? (
                    <Card className='w-[300px] md:w-[450px] px-2 py-6'>
                        <CardContent className='flex flex-col space-y-2'>
                            {['h-24', 'h-32', 'h-32', 'h-12'].map((classes, index) => (
                                <Skeleton key={index} className={classes} />
                            ))}
                        </CardContent>
                    </Card>
                ) : (
                    <div className='flex flex-col space-y-2'>
                        <Card className='w-[300px] md:w-[450px]'>
                            <CardHeader>
                                <CardTitle className='flex flex-row items-center justify-between'>
                                    <div>Swap</div>
                                    <div className='flex flex-row space-x-1'>
                                        <TooltipProvider>
                                            <Tooltip delayDuration={300}>
                                                <TooltipTrigger asChild>
                                                    <RotateCw size={16} onClick={refreshData} className='cursor-pointer' />
                                                </TooltipTrigger>
                                                <TooltipContent className='max-w-[18rem] md:max-w-[26rem] text-center'>
                                                    Refresh data
                                                </TooltipContent>
                                            </Tooltip>
                                        </TooltipProvider>
                                    </div>
                                </CardTitle>
                                <CardDescription>STX 5 exchange</CardDescription>
                                <div className='text-center'>
                                    Current STX token price is $ {stxAmount}
                                </div>
                            </CardHeader>
                            <Form {...form}>
                                <form onSubmit={form.handleSubmit(onSubmit)} autoComplete='off'>
                                    <CardContent className='flex flex-col space-y-2'>
                                        <div className='rounded-lg border-2 py-2 px-6'>
                                            <p>Pay with</p>
                                            <div className='grid md:grid-cols-2 gap-y-2 md:gap-x-2 items-center justify-center py-2 w-full'>
                                                <div className='text-4xl text-center md:text-start'>
                                                    {parseInt(form.watch('stx_amount')) * parseFloat(stxAmount)}
                                                </div>
                                                <div className='flex flex-row items-center'>
                                                    <div className='py-1 px-2 mr-6 border-2 rounded-l-full z-10 w-full'>
                                                        <FormField
                                                            control={form.control}
                                                            name='payment_method'
                                                            render={({ field }) => (
                                                                <FormItem className='w-full px-2'>
                                                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                                        <FormControl>
                                                                            <SelectTrigger className='border-none focus:bg-none px-8 md:px-2'>
                                                                                <SelectValue placeholder='Select payment method' />
                                                                            </SelectTrigger>
                                                                        </FormControl>
                                                                        <SelectContent>
                                                                            {paymentMethod.map((name) => (
                                                                                <SelectItem key={name} value={name}>
                                                                                    {name}
                                                                                </SelectItem>
                                                                            ))}
                                                                        </SelectContent>
                                                                    </Select>
                                                                    <FormMessage />
                                                                </FormItem>
                                                            )}
                                                        />
                                                    </div>
                                                    <div className='-ml-12 z-20'>
                                                        <Image src={`/assets/swap/${form.watch('payment_method')}.svg`} alt={form.watch('payment_method')} width={75} height={75} className='z-20' />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className='hidden md:flex flex-col md:flex-row items-center justify-between space-y-2 space-x-0 md:space-y-0 md:space-x-2 text-sm pr-2'>
                                                <div>$ {(parseInt(form.watch('stx_amount')) * parseFloat(stxAmount))}</div>
                                                <div className='mr-1'>
                                                    1 {form.watch('payment_method')} = $ {parseFloat(stxAmount).toLocaleString(undefined, { minimumFractionDigits: 3 })}
                                                </div>
                                            </div>
                                        </div>

                                        <div className='rounded-lg border-2 py-2 px-6'>
                                            <p>Receive</p>
                                            <div className='grid md:grid-cols-2 gap-y-2 md:gap-x-2 items-center justify-center py-2 w-full'>
                                                <div>
                                                    <FormField
                                                        control={form.control}
                                                        name='stx_amount'
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                                    <FormControl>
                                                                        <SelectTrigger className='border-white'>
                                                                            <SelectValue placeholder='Select number of tokens' />
                                                                        </SelectTrigger>
                                                                    </FormControl>
                                                                    <SelectContent>
                                                                        {stx5Amount.map((number) => (
                                                                            <SelectItem key={number} value={number}>
                                                                                {number}
                                                                            </SelectItem>
                                                                        ))}
                                                                    </SelectContent>
                                                                </Select>
                                                                <FormMessage />
                                                            </FormItem>
                                                        )}
                                                    />
                                                </div>
                                                <div className='flex flex-row items-center'>
                                                    <div className='py-1 px-2 mr-6 border-2 rounded-l-full z-10 w-full'>
                                                        <FormField
                                                            control={form.control}
                                                            name='stx5_token'
                                                            render={({ field }) => (
                                                                <FormItem className='w-full px-2'>
                                                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                                        <FormControl>
                                                                            <SelectTrigger className='border-none focus:bg-none'>
                                                                                <SelectValue placeholder='Select payment method' />
                                                                            </SelectTrigger>
                                                                        </FormControl>
                                                                        <SelectContent>
                                                                            {stx5.map((name) => (
                                                                                <SelectItem key={name} value={name}>
                                                                                    {name}
                                                                                </SelectItem>
                                                                            ))}
                                                                        </SelectContent>
                                                                    </Select>
                                                                    <FormMessage />
                                                                </FormItem>
                                                            )}
                                                        />
                                                    </div>
                                                    <div className='-ml-12 z-20'>
                                                        <Image src='/assets/swap/STX.svg' alt='STX 5' width={75} height={75} className='z-20' />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className='hidden md:flex flex-col md:flex-row items-center justify-between space-y-2 space-x-0 md:space-y-0 md:space-x-2 text-sm pr-2'>
                                                <div>$ {(parseInt(form.watch('stx_amount')) * parseFloat(stxAmount))}</div>
                                                <div className='mr-1'>
                                                    1 {form.watch('stx5_token')} = $ {parseFloat(stxAmount)}
                                                </div>
                                            </div>
                                        </div>
                                    </CardContent>
                                    <CardFooter className='flex flex-row space-x-2 w-full items-center'>
                                        <Button className='w-full' disabled={!isConnected || swaping} >
                                            {swaping && <Loader2 className='animate-spin mr-2' size={15} />}
                                            {swaping ? 'Trading...' : 'Trade'}
                                        </Button>
                                    </CardFooter>
                                </form>
                            </Form>
                        </Card>

                        <div className='py-4'>
                            <h1 className='text-2xl text-center'>Top 5 STX DApps</h1>
                            <div className='flex flex-col space-y-2 p-4'>

                                <div className='flex flex-row w-full justify-between items-center'>
                                    <div className='flex flex-row space-x-2 items-center'>
                                        <Image height='30' width='30' src='/assets/swap/stackswap.svg' alt='DApps' className='rounded border' />
                                        <div className='text-lg md:text-xl'>
                                            Stackswap
                                        </div>
                                    </div>
                                    <div className='text-sm text-accent-foreground/80'>
                                        1 STX = $ 1.940500
                                    </div>
                                </div>

                                <div className='flex flex-row w-full justify-between items-center'>
                                    <div className='flex flex-row space-x-2 items-center'>
                                        <Image height='30' width='30' src='/assets/swap/Arkadiko.svg' alt='DApps' className='rounded border' />
                                        <div className='text-lg md:text-xl'>
                                            Arkadiko
                                        </div>
                                    </div>
                                    <div className='text-sm text-accent-foreground/80'>
                                        1 STX = $ 1.992900
                                    </div>
                                </div>

                                <div className='flex flex-row w-full justify-between items-center'>
                                    <div className='flex flex-row space-x-2 items-center'>
                                        <Image height='30' width='30' src='/assets/swap/welshcorgicoin.png' alt='DApps' className='rounded border' />
                                        <div className='text-lg md:text-xl'>
                                            Welshcorgicoin
                                        </div>
                                    </div>
                                    <div className='text-sm text-accent-foreground/80'>
                                        1 STX = $ 1.929400
                                    </div>
                                </div>

                                <div className='flex flex-row w-full justify-between items-center'>
                                    <div className='flex flex-row space-x-2 items-center'>
                                        <Image height='30' width='30' src='/assets/swap/gammaformerlystxnft.png' alt='DApps' className='rounded border' />
                                        <div className='text-lg md:text-xl'>
                                            Gama
                                        </div>
                                    </div>
                                    <div className='text-sm text-accent-foreground/80'>
                                        1 STX = $ 1.923500
                                    </div>
                                </div>

                                <div className='flex flex-row w-full justify-between items-center'>
                                    <div className='flex flex-row space-x-2 items-center'>
                                        <Image height='30' width='30' src='/assets/swap/ALEX.png' alt='DApps' className='rounded border' />
                                        <div className='text-lg md:text-xl'>
                                            Alex
                                        </div>
                                    </div>
                                    <div className='text-sm text-accent-foreground/80'>
                                        1 STX = $ 1.940500
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                )}
            </div>
        </MaxWidthWrapper>
    )
}
