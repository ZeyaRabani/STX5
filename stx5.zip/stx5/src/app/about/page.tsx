"use client"

import MaxWidthWrapper from '@/components/MaxWidthWrapper'
import Image from 'next/image'

interface Feature {
    title: string;
    description: string;
}

const features: Feature[] = [
    {
        title: 'Real-Time DApp Rankings',
        description: 'Stay updated with the top 5 DApps on the Stacks blockchain. Our app provides real-time rankings based on usage and popularity, ensuring you always know which DApps are leading the way.'
    },
    {
        title: 'Token Price Tracking',
        description: 'Get accurate and current token prices for each of the top DApps. With integrated price data, you can easily track and compare the value of your favorite DApps.'
    },
    {
        title: 'User-Friendly Interface',
        description: 'Enjoy a clean, intuitive interface designed for easy navigation and quick access to the information you need. STX 5 ensures a seamless experience whether you\'re a novice or a seasoned blockchain enthusiast.'
    },
    {
        title: 'Comprehensive Insights',
        description: 'Gain valuable insights into each DApp’s performance with detailed statistics and analysis. Our app aggregates essential data to help you make informed decisions in the dynamic world of decentralized applications.'
    }
];

const FeatureCard: React.FC<Feature> = ({ title, description }) => (
    <div className='relative w-64 p-6 my-4 bg-gray-200 shadow-xl rounded-3xl'>
        <div className=' text-gray-800'>
            <p className='text-xl font-semibold'>{title}</p>
            <div className='flex space-x-2 font-medium text-basic'>
                <p>{description}</p>
            </div>
        </div>
    </div>
);

export default function Page() {
    return (
        <MaxWidthWrapper>
            <div className='flex flex-wrap-reverse md:grid md:grid-cols-2 pb-8 md:pb-0 px-0 md:px-12'>

                <div className='md:flex md:flex-col md:justify-center'>
                    <h2 className='self-center mb-4 text-2xl font-semibold tracking-wider md:text-4xl'>Empowering Your Portfolio with the Future of Finance</h2>
                    <p className='self-center text-xl tracking-wide text-justify py-2'>
                        Introducing STX 5: a simple, user-friendly app that connects to an API to showcase the top 5 DApps on the Stacks blockchain. Get real-time data on each DApp&apos;s usage and token prices, providing a quick and comprehensive overview for enthusiasts and investors alike.
                    </p>
                </div>

                <div className='lg:p-10'>
                    <Image src='/assets/home/hero.svg' height={500} width={500} quality={100} alt='img' />
                </div>

            </div>

            {/* <IndexPreformance /> */}

            {/* <div className='mb-12 text-center'>
                <h1 className='text-4xl font-bold leading-10 sm:text-5xl sm:leading-none md:text-6xl'>Formula Used</h1>
            </div>

            <div className='flex flex-col items-center justify-center pb-8'>
                <h1 className='text-xl'>
                    Formula = (Sum of Current Price of token) / (Number of tokens) $
                </h1>
            </div> */}

            <div className='mb-12 text-center'>
                <h1 className='text-4xl font-bold leading-10 sm:text-5xl sm:leading-none md:text-6xl'>Features</h1>
            </div>

            <div className='flex items-center justify-center pb-8'>
                <div className='grid grid-cols-1 gap-4 md:gap-12 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4'>
                    {features.map((feature, index) => (
                        <FeatureCard key={index} {...feature} />
                    ))}
                </div>
            </div>

        </MaxWidthWrapper>
    )
}
