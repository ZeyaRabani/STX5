import type { Metadata } from 'next'
import './globals.css'
import { cn } from '@/lib/utils'
import { WalletProvider } from '@/context/WalletContext'
import Navbar from '@/components/Navbar'
import { Toaster } from '@/components/ui/sonner'
import ScrollToTopBtn from '@/components/ScrollToTopBtn'

export const metadata: Metadata = {
  title: 'STX 5',
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang='en'>
      <body className={cn('min-h-screen bg-background antialiased font-sansSerif')}>
        <WalletProvider>
          <Navbar />
          <main className='flex-grow flex-1 pt-[4.5rem]'>
            {children}
          </main>
          <ScrollToTopBtn />
          <Toaster richColors closeButton />
        </WalletProvider>
      </body>
    </html>
  );
}
